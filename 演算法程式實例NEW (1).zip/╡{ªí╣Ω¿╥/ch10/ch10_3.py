# ch10_3.py
data = [10, 30, 90, 77, 65]
max = data[0]
for num in data:
    if num > max:
        max = num
print("最大值 : ", max)








