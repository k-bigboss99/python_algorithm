# ch6_1.py
btree = [0] * 16
print(type(btree))
print(btree)







    
