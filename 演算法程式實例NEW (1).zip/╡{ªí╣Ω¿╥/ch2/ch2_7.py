# ch2_7.py
from array import *
x = array('i', [5, 15, 25, 35, 45])     # 建立無號整數陣列

i = x.index(35)
print(i)











