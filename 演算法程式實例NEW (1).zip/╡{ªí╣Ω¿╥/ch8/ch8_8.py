# ch8_8.py
import hashlib

print(hashlib.algorithms_available)         # 列出此平台可使用的哈希演算法









