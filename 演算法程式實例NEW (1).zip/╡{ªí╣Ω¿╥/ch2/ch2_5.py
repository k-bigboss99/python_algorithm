# ch2_5.py
from array import *
x = array('i', [5, 15, 25, 35, 45])     # 建立無號整數陣列

x.remove(25)
for data in x:
    print(data)









